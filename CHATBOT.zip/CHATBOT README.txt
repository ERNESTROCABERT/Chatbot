# Chatbot Project
This is a simple chatbot developed using Python and Microsoft Bot Framework. It responds to user inputs like greetings and help commands.
## Environment Setup
1. Make sure you have Python installed on your system.
2. Install the necessary dependencies by running the following command:
   ```bash
   pip install -r requirements.txt
conda env create -f environment.yml
## Environment Variables
Before running the bot, make sure to set up the following environment variables in a `.env` file:

- `MICROSOFT_APP_ID`: Your Microsoft App ID.
- `MICROSOFT_APP_PASSWORD`: Your Microsoft App Password.

Example `.env` file:
```bash
MICROSOFT_APP_ID=<Your-App-ID>
MICROSOFT_APP_PASSWORD=<Your-App-Password>
## How to Run the Bot
1. Activate your virtual environment (if you have one):
   ```bash
   conda activate <environment_name>
python chatbot.py
http://localhost:3978/api/messages

