# Import Required Libraries
from botbuilder.core import ActivityHandler, TurnContext, BotFrameworkAdapter, BotFrameworkAdapterSettings
from botbuilder.schema import Activity, SuggestedActions, CardAction
from flask import Flask, request
import os
import asyncio

# Define the Bot Class
class SimpleBot(ActivityHandler):
    async def on_message_activity(self, turn_context: TurnContext):
        user_message = turn_context.activity.text.lower()

        # Initialize response message
        response_message = ""

        # Handle different user inputs
        if "hello" in user_message or "hi" in user_message:
            response_message = "Hello! How can I assist you today?"
        elif "help" in user_message:
            response_message = "I can help you with the following:\n- Get information\n- Chat with me"
        elif "bye" in user_message:
            response_message = "Goodbye! Have a great day!"
        else:
            response_message = f"You said: {user_message}"

        # Create an Activity instance for the response
        response_activity = Activity(type="message", text=response_message)

        # Optional: Add suggested actions
        if "help" in user_message:
            suggested_actions = SuggestedActions(
                actions=[
                    CardAction(title="Get Information", type="imBack", value="Get Information"),
                    CardAction(title="Chat with Me", type="imBack", value="Chat with Me"),
                    CardAction(title="Learn More", type="imBack", value="Learn More")
                ]
            )
            response_activity.suggested_actions = suggested_actions

        # Send the response back
        await turn_context.send_activity(response_activity)

# Configure the Bot Adapter
app_id = os.getenv("MicrosoftAppId", "")  # Replace with your App ID
app_password = os.getenv("MicrosoftAppPassword", "")  # Replace with your App Password
settings = BotFrameworkAdapterSettings(app_id, app_password)
adapter = BotFrameworkAdapter(settings)

# Set Up Flask App
app = Flask(__name__)

# Handle POST requests to the /api/messages endpoint
@app.route("/api/messages", methods=["POST"])
async def messages():
    body = await request.get_json()
    activity = Activity().deserialize(body)

    auth_header = request.headers.get("Authorization", "")
    response = await adapter.process_activity(activity, auth_header, SimpleBot())
    return response

# Run the Flask App
if __name__ == "__main__":
    app.run(port=3978)
