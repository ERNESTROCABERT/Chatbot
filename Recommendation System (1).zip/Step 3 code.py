import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load preprocessed training data
train_data = pd.read_csv("C:\\Users\\hp\\Downloads\\processed_train.csv")

# Step 1: Create TF-IDF Matrix (if not already created)
vectorizer = TfidfVectorizer(max_features=1000)  # Adjust max_features as needed
tfidf_matrix = vectorizer.fit_transform(train_data['processed_review_text'])

# Step 2: Calculate Cosine Similarity Matrix
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Step 3: Define Recommendation Function
def get_recommendations(product_name, cosine_sim=cosine_sim, df=train_data):
    # Verify if the product exists in the dataset
    if product_name not in df['name'].values:
        return "Product not found in the dataset."
    
    # Get index of the product in the dataset
    idx = df.index[df['name'] == product_name].tolist()[0]

    # Get similarity scores for this product with all others
    sim_scores = list(enumerate(cosine_sim[idx]))

    # Sort products by similarity score in descending order
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

    # Get top 5 most similar products (excluding itself)
    sim_scores = sim_scores[1:6]  # Skip the first item (itself)

    # Retrieve names of the recommended products
    product_indices = [i[0] for i in sim_scores]
    return df['name'].iloc[product_indices], sim_scores  # Return both names and scores for use outside

# Step 4: Test and Evaluate the Recommendation System

# 1. Manual Evaluation: Print recommendations for a specific product
product_name = "Fire Kids Edition Tablet, 7 Display, Wi-Fi, 16 GB, Green Kid-Proof Case"  # Example product name
print(f"Recommendations for '{product_name}':")
recommended_products, sorted_scores = get_recommendations(product_name)
print(recommended_products)

# 2. Display similarity scores for evaluation
print(f"\nSimilarity scores for '{product_name}':")
for i, (index, score) in enumerate(sorted_scores, start=1):
    print(f"{i}. {train_data['name'].iloc[index]} - Score: {score}")

# Optional: Save Example Results for Report
# Save recommendations and similarity scores to CSV for documentation in the report
results = pd.DataFrame({
    "Product Name": [product_name],
    "Recommendations": [recommended_products.values.tolist()]
})
results.to_csv("C:\\Users\\hp\\Downloads\\recommendation_results.csv", index=False)

# Save similarity scores for the chosen product
similarity_df = pd.DataFrame({
    "Recommended Product": [train_data['name'].iloc[i[0]] for i in sorted_scores],
    "Similarity Score": [i[1] for i in sorted_scores]
})
similarity_df.to_csv("C:\\Users\\hp\\Downloads\\similarity_scores.csv", index=False)

print("\nEvaluation completed. Results saved for documentation.")
