import tkinter as tk
from tkinter import messagebox
import pandas as pd

# Sample recommendation function (replace with your actual function or import it)
def get_recommendations(product_name, df):
    # Example data - replace with your actual recommendation logic and data
    if product_name not in df['name'].values:
        return "Product not found in the dataset."
    
    # Dummy recommendation for demonstration purposes
    idx = df.index[df['name'] == product_name].tolist()[0]
    sim_scores = [(i, 0.8 - (i * 0.1)) for i in range(5)]
    product_indices = [i[0] for i in sim_scores]
    recommendations = df['name'].iloc[product_indices]
    return recommendations

# Load the processed data - replace with your actual path
data = pd.read_csv("C:\\Users\\hp\\Downloads\\processed_train.csv")

# Function to fetch and display recommendations
def show_recommendations():
    product_name = entry.get()
    recommendations = get_recommendations(product_name, data)
    if isinstance(recommendations, str):  # If no recommendations found
        messagebox.showinfo("Result", recommendations)
    else:
        result_text = "\n".join(recommendations)
        messagebox.showinfo("Recommendations", result_text)

# Create the main tkinter window
root = tk.Tk()
root.title("Product Recommendation System")

# Create GUI elements
tk.Label(root, text="Enter Product Name:").pack(pady=10)
entry = tk.Entry(root, width=50)
entry.pack(pady=5)

# Button to get recommendations
tk.Button(root, text="Get Recommendations", command=show_recommendations).pack(pady=10)

# Run the GUI loop
root.mainloop()
