import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load preprocessed training data
train_data = pd.read_csv("C:\\Users\\hp\\Downloads\\processed_train.csv")

# Step 1: Create TF-IDF Matrix
vectorizer = TfidfVectorizer(max_features=1000)
tfidf_matrix = vectorizer.fit_transform(train_data['processed_review_text'])

# Step 2: Calculate Cosine Similarity
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Step 3: Define Recommendation Function
def get_recommendations(product_name, cosine_sim=cosine_sim, df=train_data):
    # Check if the product name exists in the dataset
    if product_name not in df['name'].values:
        return "Product not found in the dataset."
    
    # Find the index of the product in the dataset
    idx = df.index[df['name'] == product_name].tolist()[0]

    # Get similarity scores for this product with all others
    sim_scores = list(enumerate(cosine_sim[idx]))

    # Sort products based on similarity scores in descending order
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

    # Get the top 5 most similar products (excluding itself)
    sim_scores = sim_scores[1:6]

    # Retrieve the product names for the recommended items
    product_indices = [i[0] for i in sim_scores]
    return df['name'].iloc[product_indices]

# Step 4: Test the Recommendation System
# Replace with an exact product name from the unique list
product_name = "Fire Kids Edition Tablet, 7 Display, Wi-Fi, 16 GB, Green Kid-Proof Case"
recommended_products = get_recommendations(product_name)
print(f"Recommendations for '{product_name}':\n", recommended_products)
